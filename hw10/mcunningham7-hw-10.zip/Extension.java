public class Extension {

  public static void main(String[] args) {
    Person[] people = PersonLoader.loadPeople();
	  
    // TODO: write extension code here
  }
}
