
/**
 * all operations will fall into one of these categories. USE THESE CATEGORIES DURING EXECUTION
 */
public enum OpType {
    LOAD, STORE, ADD, MUL, SUB, DIV, MOD;
}
