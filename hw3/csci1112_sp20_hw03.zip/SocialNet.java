/*-----------------------------------------------------------------------------
GWU CSCI1112 Fall 2019
author: <your name>

This class encapsulates the logic necessary to sort social networking data
based on differentials.
------------------------------------------------------------------------------*/
import java.awt.*;
import java.awt.image.*;
import java.lang.*;
import java.util.*;
import java.text.*;

public class SocialNet {
    //------------------------------------------------------------------------- 
    // Base Problems
    //------------------------------------------------------------------------- 
    /// A referential copy (shallow copy of each row) and not an element-wise 
    /// copy (deep copy).  We are sorting elements with respect to the original
    /// data rather than generating a new set of data.
    /// @param posts data containing the rows to reference
    /// @return the shallow copy of rows
    public static int[][] createView(int[][] posts) {
        // TODO : Implement Here
        return null;
    }
 
    //------------------------------------------------------------------------- 
    /// Compute the differential between "ups" (at index 1) and "downs" 
    /// (at index 2). The differential is not maintained in the data but is a 
    /// virtual field derived by the calculation performed here
    public static int differential(int[] post) {
        // TODO : Implement Here
        return 0;
    }

    //------------------------------------------------------------------------- 
    /// Performs a comparison between two posts that is equivalent to a less
    /// than operation so that a sort can use this function to order posts.
    /// The less than criteria is an evaluation between the differentials of
    /// two posts.
    /// @param post1 a post record that is used as the "left" operand for a
    ///        less than comparison 
    /// @param post2 a post record that is used as the "right" operand for a
    ///        less than comparison 
    /// @return returns true if the computed differential for post1 is less than
    ///         the computed differential for post2; otherwise, returns false 
    ///         (false implies that differential for post1 is greater than or
    ///         equal to post2)
    public static boolean lessThan(int[] post1, int[] post2) {
        // TODO : Implement Here
        return false;
    }
    //------------------------------------------------------------------------- 
    /// Swaps references to posts.  Note that this is a "shallow" swap and not 
    /// a "deep" swap
    /// @param view A shallow copy of a set of posts 
    /// @param i the index of the first reference to swap
    /// @param j the index of the second reference to swap
    public static void swapPosts(int[][] view, int i, int j) {
        // TODO : Implement Here
    }

    //------------------------------------------------------------------------- 
    /// Sorts (shallow) a set of references to posts in descending order 
    /// subject to the differential between ups and downs using one of
    /// the iterative sorts we discussed in class, i.e. selection, bubble, or 
    /// insertion sort
    /// @param view A shallow copy of a set of posts 
    /// @return a set of profile information containing a count of 
    ///         0: allocations, 1:comparisons, and 2: swaps
    public static int[] iterativeSort(int[][] view) {
        // profile[0:allocs (ignore profile), 1:comparisons, 2:swaps]
        int[] profile = new int[3];

	// TODO : Implement Here
	
        return profile;
    }

    //------------------------------------------------------------------------- 
    // Extension Problems
    //------------------------------------------------------------------------- 
    /// Sorts (shallow) a set of references to posts in descending order 
    /// subject to the differential between ups and downs using a recursive
    /// approach, i.e. quicksort.
    /// @param view A shallow copy of a set of posts 
    /// @return a set of profile information containing a count of 
    ///         0: allocations, 1:comparisons, and 2: swaps
    public static int[] recursiveSort(int[][] view) {
        // profile[0:allocs (ignore profile), 1:comparisons, 2:swaps]
        int[] profile = new int[3];

        // TODO : Implement Here
        return profile;
    }
}


