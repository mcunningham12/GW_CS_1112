public class ShoppingCart {

    private int count;
    private Product[] data;
  
    public ShoppingCart() {
        count = 0;
        data = new Product[1];
    }

    public boolean add(Product product) {
        return false;
    }

    public boolean addAt(Product product, int index){
        return false;
    }

    public boolean remove(Product product) {
        return false;
    }

    public double checkout() {
        return 0.0;
    }

    public int count() {
        return 0;
    }

    public Product get(int index) {
        return null;
    }

    public void clear() {

    }

    public boolean isEmpty() {
        return false;
    }

    public boolean contains(Product product){
        return false;
    }

    //insert any extra functions you want below this point

}
