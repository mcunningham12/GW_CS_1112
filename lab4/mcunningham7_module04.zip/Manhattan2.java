public class Manhattan2 {
    static int p =1;
    //p is a global variable so it can be called in countPaths and the void
    //p counts the amount of possible paths so the number can be printed
    public static void main (String[] argv)
    {
        // Test case 1:
	int r = 1, c = 1;
	int n = countPaths (r, c, "[1,1]");
	System.out.println ("r=" + r + " c=" + c + " => n=" + n);

        // Test case 2:
	p = 1; //reset p after case 1
    r = 5;
	c = 3;
	n = countPaths (r, c, "[5,3]");
	System.out.println ("r=" + r + " c=" + c + " => n=" + n);
    }


    static int countPaths (int numRows, int numCols, String partialPath)
    {
	// Bottom out case: this is more complicated now.
    // change finalStr wherever it is previously manipulated to include the counter p
        if (numRows == 0) {
            // Make the path across the columns.
            String finalStr = "Path #" + p + " " + partialPath;
            p++;
            for (int c=numCols-1; c>=0; c--) {
                finalStr += " -> [0," + c + "]";
            }
            System.out.println (finalStr);
            return 1;
        }
        else if (numCols == 0) {
          // Make the path down rows.
          String finalStr = "Path #" + p + " " + partialPath;
          p++;
            for (int r=numRows-1; r>=0; r--) {
                finalStr += " -> [" + r + ",0]";
            }
            System.out.println (finalStr);
            return 1;
        }

    
	// Otherwise, reduce problem size.

        // Downwards.
	String downpathStr = partialPath + " -> " + "[" + (numRows-1) + "," + numCols + "]";
        int downCount = countPaths (numRows-1, numCols, downpathStr);

        // Rightwards.
	String rightpathStr = partialPath + " -> " + "[" + (numRows) + "," + (numCols-1) + "]";
	int rightCount = countPaths (numRows, numCols-1, rightpathStr);

        // Add the two.
	return (downCount + rightCount);
    }
}
