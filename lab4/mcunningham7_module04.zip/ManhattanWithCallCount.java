public class ManhattanWithCallCount {
    static int call=0;
    public static void main (String[] argv)
    {
        // Test case 1: go from (2,2) to (0,0)
	int r = 1;
	int c = 1;
    call++;
	int n = countPaths (r, c);
	System.out.println ("r=" + r + " c=" + c + " => n=" + n);
    System.out.println("calls: " + call);
    //reset call
    call = 0;
    
        // Test case 2: go from (5,7) to (0,0)
	r = 5;
	c = 7;
	call++;
    n = countPaths (r, c);
	System.out.println ("r=" + r + " c=" + c + " => n=" + n);
    System.out.println ("calls: " + call);
    }


    static int countPaths (int numRows, int numCols) {
    // Bottom-out cases
    if ( (numRows == 0) || (numCols == 0) ) {
	    return 1;
	}

	// Otherwise, reduce to two sub-problems and add.
    int downCount = countPaths (numRows-1, numCols);
    call++;
    int rightCount = countPaths (numRows, numCols-1);
    return (downCount + rightCount);
    }
}
